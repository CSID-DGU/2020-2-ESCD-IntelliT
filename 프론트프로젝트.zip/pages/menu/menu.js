// pages/menu/menu.js
Page({

  /**
   * Page initial data
   */
  data: {
    image_bagel: '/image/bagel.png',
    image_cake: '/image/cake.png',
    image_americano: '/image/americano.png',
    image_cafemoca: '/image/cafemoca.png',

    

    show: false,
    showimage:false,
  },

  /**결제창 팝업 */

  showPopup() {
    this.setData({ show: true });
  },

  /**이미지 보여주기 */
  showImage(){
    this.setData({showimage:true});
  },

  onClose() {
    this.setData({ show: false });
  },

  onCloseImage() {
    this.setData({ showimage: false });
  },

  checkPay() {
    wx.switchTab({
      url: '/pages/pay/pay',
    })
  },













  /**수량 변경 콘솔로그로 찍어보기 */
  onChange(event) {
    console.log(event.detail);
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  },


  

  
})